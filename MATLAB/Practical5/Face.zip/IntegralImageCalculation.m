function Iout = IntegralImageCalculation(Iin)

% Calculate the integral image
%/////////// To be completed at step 3\\\\\\\\\\\\\


end